const express=require('express');
const app=express();
const MedsRoute=require('./APIs/Routes/Meds');
const mongoose=require('mongoose');
const bodyParser=require('body-parser');
const cors=require('cors');
const URL='mongodb+srv://shahzadali:Qudeer%40125@medsinfodataset.y0wqtqy.mongodb.net/MediCatch_Meds'

mongoose.connect(URL);
mongoose.connection.on('Error',err=>{
    console.log("Mongoose Connection Failed due to : ",err);
})

mongoose.connection.on('connected',connected=>{
    console.log("Mongoose Connection Successful");
})

app.use(cors());
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());


app.use('/Meds',MedsRoute);

app.use((req,res,next)=>{
    res.status(404).json({
        Error:"Page Not Found"
    })
})

module.exports=app;