const express=require('express');
const router=express.Router();
const mongoose=require('mongoose')
const MedsInfo =require('../Models/MedsSchema');


router.get('/',async(req,res,next)=>{
    console.log("Data got Processing")
    MedsInfo.find({})
    .then(result=>{
        console.log(result);
        res.status(200).send(result);
    })
    console.log("Data got Succesfully");
})

router.post('/',(req,res,next)=>{
    const addMed=new MedsInfo({
    _id:new mongoose.Types.ObjectId,
    id:req.body.id,
    name:req.body.name,
    substitute0: req.body.substitute0,
    substitute1: req.body.substitute1,
    substitute2: req.body.substitute2,
    substitute3: req.body.substitute3,
    substitute4:req.body.substitute4,
    sideEffect0: req.body.sideEffect0,
    sideEffect1: req.body.sideEffect1,
    sideEffect2: req.body.sideEffect2,
    sideEffect3: req.body.sideEffect3,
    sideEffect4: req.body.sideEffect4,
    sideEffect5: req.body.sideEffect5,
    sideEffect6: req.body.sideEffect6,
    sideEffect7: req.body.sideEffect7,
    use0: req.body.use0,
    use1: req.body.use1,
    use2: req.body.use2,
    use3: req.body.use3,
    use4: req.body.use4,
    Chemical_Class: req.body.Chemical_Class,
    Therapeutic_Class: req.body.Therapeutic_Class

    })

    addMed.save()
    .then(result=>{
        console.log("Data Posted Successfully");
        console.log(result);
        res.status(200).send(result);
    })
});

module.exports=router;