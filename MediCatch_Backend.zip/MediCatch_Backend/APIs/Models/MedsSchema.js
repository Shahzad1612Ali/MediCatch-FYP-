const mongoose=require('mongoose');

const meds_Schema=new mongoose.Schema({
    _id:mongoose.Schema.Types.ObjectId,
    id: Number,
    name: String,
    substitute0: String,
    substitute1: String,
    substitute2: String,
    substitute3: String,
    substitute4: String,
    sideEffect0: String,
    sideEffect1: String,
    sideEffect2: String,
    sideEffect3: String,
    sideEffect4: String,
    sideEffect5: String,
    sideEffect6: String,
    sideEffect7: String,
    use0: String,
    use1: String,
    use2: String,
    use3: String,
    use4: String,
    Chemical_Class: String,
    Therapeutic_Class: String
},{
    collection:"MedsInfo"
})

module.exports=mongoose.model('MedsInfo', meds_Schema);
